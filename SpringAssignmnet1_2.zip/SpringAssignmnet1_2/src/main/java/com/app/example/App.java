package com.app.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.app.example.beans.Movie;
import com.app.example.beans.Movie2;
import com.app.example.beans.Selectmovie;
import com.app.example.beans.Student;

public class App{
	Movie movie1;
	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"beans.xml");
		Movie movie = (Movie) context.getBean("movie");
		System.out.println("output is --"+movie.toString());
		Selectmovie selectmovie= (Selectmovie) context.getBean("selectmovie");
		System.out.println("output is --"+selectmovie.toString());
		Student student1 = (Student) context.getBean("student1");
		System.out.println("output is --"+student1.toString());
		Student student2 = (Student) context.getBean("student2");
		System.out.println("output is --"+student2.toString());
		// close the context
		context.close();
		
	}
}
