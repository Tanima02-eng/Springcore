package com.app.example;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.app.example.beans.CPA;

public class App2 {
	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"assignment.xml");
		CPA cpa = (CPA) context.getBean("cpa");

		System.out.println("EXC:--- ");
		((CPA) cpa).getPlayersByCountry("Aus");
		
		// close the context
		context.close();
}
}