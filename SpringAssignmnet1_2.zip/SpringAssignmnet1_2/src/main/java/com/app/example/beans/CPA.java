package com.app.example.beans;

	import java.util.List;
	import java.util.Map;
	import java.util.Map.Entry;

	public class CPA {
		
		private Map <Country, List <Player> > map ;
		
		public void getPlayersByCountry(String countryName) {
			System.out.println("ENTRY :--- "+countryName);
			
			for (Entry<Country, List<Player>>  entry : map.entrySet()) {
		
				
				if ((entry.getKey().getCountryName().trim()).equals(countryName.trim())){
					System.out.println("===="+entry.getValue());
					for(Player player : entry.getValue()) {
						System.out.println("===="+player);
						System.out.println("PLAYER : "+player.toString());
					}
				}
			}
			
		}

		public Map<Country, List<Player>> getMap() {
			return map;
		}

		public void setMap(Map<Country, List<Player>> map) {
			this.map = map;
		}
		
		
		
	}
	
	
