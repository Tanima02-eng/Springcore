package com.app.example.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;


public class Movie2 {
	
		   private String movieId;
		   private String movieName;
		   private String movieActor;
		   
		
		public String getMovieId() {
			return movieId;
		}
		public void setMovieId(String movieId) {
			this.movieId = movieId;
		}
		public String getMovieName() {
			return movieName;
		}
		public void setMovieName(String movieName) {
			this.movieName = movieName;
		}
		public String getMovieActor() {
			return movieActor;
		}
		public void setMovieActor(String movieActor) {
			this.movieActor = movieActor;
		}
		   

}
