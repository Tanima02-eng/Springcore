package com.app.example.beans;

import com.app.example.beans.Test;

import java.util.Iterator;
import java.util.List;


public class Student {
	
	private String studentId;  
	private String studentName; 
	private List<Test> tests;  
	
	
	
	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentName=" + studentName + ", answers=" + tests.toString() + "]";
	}



	public Student(String studentId, String studentName, List<Test> tests) {  
	    super();  
	    this.studentId = studentId;  
	    this.studentName = studentName;  
	    this.tests = (List<Test>) tests;  
	    
	    
}
	public void displayInfo(){  
	    System.out.println(studentId+" "+studentName);  
	    System.out.println("answers are:");  
	    Iterator<Test> itr=tests.iterator();  
	    while(itr.hasNext()){  
	        System.out.println(itr.next());    
	   
	    }
	    
	}
}
	
	
