package com.app.example.beans;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;


public class Selectmovie {
	
	   @Autowired
	   @Qualifier("movieb")
	   private Movie2 movie2;
	  

	   @Override
		public String toString() {
			return "Movie2 [movieId=" + movie2.getMovieId() + ", movieName=" + movie2.getMovieName() + ", movieActor=" + movie2.getMovieActor() + "]";
			
	   }
}