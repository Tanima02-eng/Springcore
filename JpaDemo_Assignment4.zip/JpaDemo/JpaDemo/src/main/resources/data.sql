insert into student
values(10001,'Ranga', 'Kol');

insert into student
values(10002,'Ravi', 'How');