package com.jpa.example.JpaDemo.controler;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.jpa.example.JpaDemo.dbmodel.Student;
import com.jpa.example.JpaDemo.service.StudentService;

@RestController		// Useful to create the RESTful webservices.
public class StudentController {

	

	// @Autowired annotation provides the automatic dependency injection.
	@Autowired
	StudentService service;

	// Save student entity in the h2 database.
	// @PostMapping annotation handles the http post request matched with the given uri.
	// @RequestBody annotation binds the http request body to the domain object.
	// @Valid annotation validates a model after binding the user input to it.
	
	//http://localhost:10090//student/save
	/*
	 * {
"id":1,
"name":"Tanima",
"address":"Kol"
}
	 */
	
	@PostMapping(value= "/student/save")
	public int save(final @RequestBody @Validated Student student) {
		
		service.save(student);
		return student.getId();
	}

	// Get all students from the h2 database.
	// @GetMapping annotation handles the http get request matched with the given uri.
	@GetMapping(value= "/student/getall", produces= "application/vnd.jcg.api.v1+json")
	public List<Student> getAll() {
		
		return service.getAll();
	}
}