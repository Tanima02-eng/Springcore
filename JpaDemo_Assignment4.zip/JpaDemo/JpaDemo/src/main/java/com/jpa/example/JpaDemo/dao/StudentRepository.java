package com.jpa.example.JpaDemo.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.jpa.example.JpaDemo.dbmodel.Student;

@Repository
public interface StudentRepository extends CrudRepository<Student, Integer>{

}
