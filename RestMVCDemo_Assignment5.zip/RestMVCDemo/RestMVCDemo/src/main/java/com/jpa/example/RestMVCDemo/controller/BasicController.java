package com.jpa.example.RestMVCDemo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.jpa.example.RestMVCDemo.dao.BasicService;

@Controller
public class BasicController {
	
	@Autowired
	BasicService basecService;
	

    @RequestMapping(value="/login", method = RequestMethod.GET)
    public String showLoginPage(ModelMap model){
        return "index";
    }
    
    
    @RequestMapping(value="/login", method = RequestMethod.POST)
    public String showWelcomePage(ModelMap model, @RequestParam int science, @RequestParam int  english){

    	int total=basecService.calculateTotal(science, english);
        model.put("total", total);
        return "welcome";
    }
    

}
