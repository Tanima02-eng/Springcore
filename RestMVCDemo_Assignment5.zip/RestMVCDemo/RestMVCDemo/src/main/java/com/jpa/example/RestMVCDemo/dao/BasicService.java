package com.jpa.example.RestMVCDemo.dao;

import org.springframework.stereotype.Service;

@Service
public class BasicService {

	
	
	public int calculateTotal(int sci,int eng) {
		return sci+eng;
		
	}
}
