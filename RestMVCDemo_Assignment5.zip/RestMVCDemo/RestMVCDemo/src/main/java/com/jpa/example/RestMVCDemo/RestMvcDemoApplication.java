package com.jpa.example.RestMVCDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.jpa.example")
public class RestMvcDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestMvcDemoApplication.class, args);
	}
	
	

}
