package com.jpa.example.RestMVCDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestMvcDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
