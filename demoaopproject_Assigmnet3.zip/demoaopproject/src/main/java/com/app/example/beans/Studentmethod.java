package com.app.example.beans;


import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import com.app.example.beans.Student;

public class Studentmethod{
	private List<Student> students;
	
	
public List<Student> getStudents() {
		return students;
	}
	public void setStudents(List<Student> students) {
		this.students = students;
	}
public void getalldetails(){
	for(Student student:this.students) {
		System.out.println(student.getStudentname());
		
		
     }
}
	 

     public void getdetailsbyid(int id) {
    	 for(Student student:this.students) {
    	        if (student.getStudentid()==id) {
    	        	System.out.println(student.getStudentname());
}
}
     }
     }

	
