package com.app.example;
import com.app.example.beans.*;


import org.springframework.context.support.ClassPathXmlApplicationContext;



public class App {
	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"beans.xml");
		Studentmethod student= (Studentmethod)context.getBean("s1method");
		student.getalldetails();

}
}
