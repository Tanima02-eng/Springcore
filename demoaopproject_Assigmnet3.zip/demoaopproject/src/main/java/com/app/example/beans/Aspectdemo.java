package com.app.example.beans;
import java.awt.Point;
import java.util.Date;
import java.time.LocalDate;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.annotation.Around;

@Aspect

public class Aspectdemo {
    
	@Around("getNamePointcut()")
	public void loggingAdvice(ProceedingJoinPoint point) {
		System.out.println("Executing loggingAdvice on details of student class()");
		Date date= new Date();
        System.out.println("Time taken to execute"+point.getSignature()+" method is:"+date);

	}
	
	@Pointcut("execution(public void com.app.example.beans.*.*(..))")
	public void getNamePointcut(){
		System.out.println("Executing Advice on Studentmethod method");
	}	
		
}